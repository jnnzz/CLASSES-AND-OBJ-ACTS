//public class Xiaomi {
//
//    //PROPERTIES
//    private String brand;
//    private double price;
//    private int storage;
//    private int ram;
//    private double size;
//
//    //CONSTRUCTORS
//    Xiaomi(){
//
//    }
//    Xiaomi(String brand, double price, int storage, int ram, double size){
//        this.brand = brand;
//        this.price = price;
//        this.storage = storage;
//        this.ram = ram;
//        this.size = size;
//    }
//
//    //METHODS
//    public void description() {
//        System.out.printf("This brand is top chuchu\n");
//    }
//
//    public void displaySpecs(){
//        System.out.println("Brand: "+brand);
//        System.out.println("Price: "+price);
//        System.out.println("Storage: "+storage);
//        System.out.printf("RAM: "+ram+"gb\n");
//        System.out.printf("Size: "+size+" inches display");
//        System.out.println();
//
//
//    }
//}
