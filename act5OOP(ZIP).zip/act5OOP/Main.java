/******************************************************************************

 NAME: JAN LORENZ L. LAROCO
 DATE: 10/2/24
 DESCRIPTION: Midterm - Lab.Act.#05 - Classes and Objects

 *******************************************************************************/
import java.util.Scanner;
public class Main
{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.printf("-----Welcome to Jan's Gadgets Store-----\n");
        System.out.println("Choose a phone with your own budget");
        System.out.println();

        System.out.printf("1. 5,000+\n");
        System.out.printf("2. 10,000+\n");
        System.out.printf("3. 15,000+\n");
        System.out.printf("4. 20,000+\n");
        System.out.println();

        System.out.printf("Choice: ");
        int choice = scanner.nextInt();
        System.out.println();

        if(choice == 1){
            //OBJECT 1
            Phones samsung1 = new Phones("Galaxy A06", 5790, 128, 4, 6.6);
            //call methods
            samsung1.info("----------SAMSUNG---------");
            samsung1.displaySpecs();
            System.out.println("--------------------------");
            System.out.println();

            //OBJECT 2
            Phones vivo1 = new Phones("Vivo Y17s", 5999, 128, 4, 6.56);
            vivo1.info("-----------VIVO-----------");
            vivo1.displaySpecs();
            System.out.println("--------------------------");
            System.out.println();

            //OBJECT 3
            Phones xiaomi1 = new Phones("Xiaomi Redmi 8A", 5490, 64, 2, 6.22);
            xiaomi1.info("----------XIAOMI----------");
            xiaomi1.displaySpecs();
            System.out.println("--------------------------");
            System.out.println();


        } else if (choice == 2) {
            //OBJECT 1
            Phones samsung2 = new Phones("Realme", 5999, 128, 6, 6.67);
            //call methods

            samsung2.description();
            samsung2.displaySpecs();
            System.out.println();

            //OBJECT 2
            Phones vivo2 = new Phones("Vivo", 5999, 256, 8, 6.5);
            vivo2.description();
            vivo2.displaySpecs();
            System.out.println();

            //OBJECT 3
            Phones xiaomi2 = new Phones("Xiaomi 9", 5699, 64, 4, 6.5);
            xiaomi2.description();
            xiaomi2.displaySpecs();
            System.out.println();

        } else if (choice == 3){
            //OBJECT 1
            Phones samsung3 = new Phones("Realme", 5999, 128, 6, 6.67);
            //call methods
            samsung3.description();
            samsung3.displaySpecs();
            System.out.println();

            //OBJECT 2
            Phones vivo3 = new Phones("Vivo", 5999, 256, 8, 6.5);
            vivo3.description();
            vivo3.displaySpecs();
            System.out.println();

            //OBJECT 3
            Phones xiaomi3 = new Phones("Xiaomi 9", 5699, 64, 4, 6.5);
            xiaomi3.description();
            xiaomi3.displaySpecs();
            System.out.println();

        } else if (choice == 4) {
            //OBJECT 1
            Phones samsung4 = new Phones("Realme", 5999, 128, 6, 6.67);
            //call methods
            samsung4.description();
            samsung4.displaySpecs();
            System.out.println();

            //OBJECT 2
            Phones vivo4 = new Phones("Vivo", 5999, 256, 8, 6.5);
            vivo4.description();
            vivo4.displaySpecs();
            System.out.println();

            //OBJECT 3
            Phones xiaomi4 = new Phones("Xiaomi 9", 5699, 64, 4, 6.5);
            xiaomi4.description();
            xiaomi4.displaySpecs();
            System.out.println();

        } else {
            System.out.println("INVALID INPUT");
        }


        scanner.close();

    }

}
