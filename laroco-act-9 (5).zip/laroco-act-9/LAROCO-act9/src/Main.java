import javax.swing.*;
import java.awt.*;

public class Main {
    public static void main(String[] args) {
        MyFrame frame = new MyFrame();  // Create and use a single instance of MyFrame

        // instance
        Student student = new Student(frame);

        // Injecting
        Jeepney jeepney = new Jeepney();
        student.setVehicle(jeepney);
        student.travelTo("Mall");

        MotorcycleTaxi motorcycleTaxi = new MotorcycleTaxi();
        student.setVehicle(motorcycleTaxi);
        student.travelTo("University of Cebu");

        Helicopter helicopter = new Helicopter();
        student.setVehicle(helicopter);
        student.travelTo("Island");

        //positions sa panels
        //position sa text
        //animation sa panels

        //decouple/coupling
        //copy text from interface
    }
}