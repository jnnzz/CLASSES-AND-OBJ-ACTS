public class Student {
    private Vehicle vehicle;
    private MyFrame frame;  // Reference to MyFrame to update infoLabelJeep

    public Student(MyFrame frame) {
        this.frame = frame;
    }

    public void setVehicle(Vehicle vehicle) {
        this.vehicle = vehicle;
    }

    public void travelTo(String destination) {
        if (vehicle != null) {
            vehicle.travel(destination); // Call the travel method of the vehicle
            String info = "Traveling to " + destination + " by " + vehicle.getClass().getSimpleName();
            frame.updateInfoLabel(info,vehicle);  // Update infoLabelJeep with travel info
        }
    }
}
