import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MyPanel extends JPanel implements ActionListener {

    final int PANEL_WIDTH = 500;
    final int PANEL_HEIGHT = 550;
    Image car;
    Image helicopter;
    Image motor;
    Image backgroundImage;
    Timer timer;
    int xVelocity = 1;
    int yVelocity = 1;
    int x = 0;
    int y = 0;
    final int CAR_WIDTH = 100; // Change to your desired width
    final int CAR_HEIGHT = 100;


    MyPanel(Image car){
//        car = new ImageIcon(getClass().getResource("jeep.png")).getImage();
//        car = car.getScaledInstance(CAR_WIDTH, CAR_HEIGHT, Image.SCALE_SMOOTH);

//        helicopter = new ImageIcon(getClass().getResource("helicopter.png")).getImage();
//        helicopter = helicopter.getScaledInstance(100, 200, Image.SCALE_SMOOTH);
//
//        motor = new ImageIcon(getClass().getResource("motor.png")).getImage();
//        motor = motor.getScaledInstance(100, 200, Image.SCALE_SMOOTH);
        this.car = car;
        this.setPreferredSize(new Dimension(PANEL_WIDTH,PANEL_HEIGHT));
        this.setBackground(Color.CYAN);
        this.setLayout(null);
        timer = new Timer(50, this);
        timer.start();

    }


    public void paint(Graphics g){

        super.paint(g);
        Graphics2D g2D = (Graphics2D) g;
        g2D.drawImage(car,x,y,null);
    }


    @Override
    public void actionPerformed(ActionEvent e){
        x = x + xVelocity;
        repaint();
    }
}
