import javax.swing.*;
import java.awt.*;


public class MyFrame extends JFrame {


    MyPanel panelMain;
    MyPanel panel1;
    MyPanel panel2;
    MyPanel panel3;
    MyPanel infoPanelJeep;
    MyPanel infoPanelHelicopter;
    MyPanel infoPanelMotor;

    JLabel label1 = new JLabel();
    JLabel label2 = new JLabel();
    JLabel label3 = new JLabel();
    JLabel labelPic1 = new JLabel();
    JLabel labelPic2 = new JLabel();
    JLabel labelPic3 = new JLabel();
    JLabel infoLabelJeep = new JLabel();
    JLabel infoLabelHelicopter = new JLabel();
    JLabel infoLabelMotor = new JLabel();

    Image road;
    Image cars;
    Image helicopter;
    Image motor;

    public void updateInfoLabel(String info, Vehicle vehicle) {
        if (vehicle instanceof Jeepney) {
            infoLabelJeep.setText(info);
        } else if (vehicle instanceof Helicopter) {
            infoLabelHelicopter.setText(info);
        } else if (vehicle instanceof MotorcycleTaxi) {
            infoLabelMotor.setText(info);
        }
    }

    MyFrame(){

//images
        cars = new ImageIcon(getClass().getResource("jeep-removebg.png")).getImage();
        cars = cars.getScaledInstance(200, 180, Image.SCALE_SMOOTH);

        road = new ImageIcon(getClass().getResource("road.jpg")).getImage();
        road = road.getScaledInstance(850, 200, Image.SCALE_SMOOTH);

        helicopter = new ImageIcon(getClass().getResource("helicopter-removebg.png")).getImage();
        helicopter = helicopter.getScaledInstance(170, 200, Image.SCALE_SMOOTH);

        motor = new ImageIcon(getClass().getResource("motor-removebg.png")).getImage();
        motor = motor.getScaledInstance(180, 200, Image.SCALE_SMOOTH);

        panelMain = new MyPanel(null);
        panel1 = new MyPanel(cars);
        panel2 = new MyPanel(helicopter);
        panel3 = new MyPanel(motor);
        infoPanelJeep = new MyPanel(null);
        infoPanelHelicopter = new MyPanel(null);
        infoPanelMotor = new MyPanel(null);

        //jeep
        infoPanelJeep.setLayout(null); //
        infoPanelJeep.setBounds(0,0,500,25);
        infoPanelJeep.setBackground(Color.BLACK);
        infoPanelJeep.add(infoLabelJeep);

        infoLabelJeep.setText("");
        infoLabelJeep.setBounds(50,0,400,25);
        infoLabelJeep.setBackground(Color.WHITE);
        infoLabelJeep.setOpaque(true);

        //helicopter
        infoPanelHelicopter.setLayout(null); //
        infoPanelHelicopter.setBounds(0,200,500,25);
        infoPanelHelicopter.setBackground(Color.BLACK);
        infoPanelHelicopter.add(infoLabelJeep);

        infoLabelHelicopter.setText("");
        infoLabelHelicopter.setBounds(50,0,400,25);
        infoLabelHelicopter.setBackground(Color.WHITE);
        infoLabelHelicopter.setOpaque(true);

        //motor
        infoPanelMotor.setLayout(null); //
        infoPanelMotor.setBounds(0,355,500,25);
        infoPanelMotor.setBackground(Color.BLACK);
        infoPanelMotor.add(infoLabelJeep);

        infoLabelMotor.setText("");
        infoLabelMotor.setBounds(50,0,400,25);
        infoLabelMotor.setBackground(Color.WHITE);
        infoLabelMotor.setOpaque(true);



        //LABEL1
        label1.setIcon(new ImageIcon(road));
        label1.setBounds(0,0,700,150);

//        labelPic1.setText("hi everyone");
//        labelPic1.setIcon(new ImageIcon(cars));
        labelPic1.setBounds(200,-20,300,200);
        labelPic1.setHorizontalAlignment(JLabel.RIGHT);//addlabelPic1

        //LABEL2
        label2.setIcon(new ImageIcon(road));
        label2.setBounds(0,0,700,150);

//        labelPic2.setIcon(new ImageIcon(helicopter));
        labelPic2.setBounds(0,0,300,150);
        labelPic2.setHorizontalAlignment(JLabel.LEFT);//addlabelPic1

        //LABEL3
        label3.setIcon(new ImageIcon(road));
        label3.setBounds(0,0,700,150);

//        labelPic3.setIcon(new ImageIcon(motor));
        labelPic3.setBounds(0,0,300,150);
        labelPic3.setHorizontalAlignment(JLabel.LEFT);//addlabelPic1

        //PANEL1
        panel1.setLayout(null); // Change layout to BorderLayout
        panel1.setBounds(0,25,500,150);
        panel1.setBackground(Color.YELLOW);

        //PANEL2
        panel2.setLayout(null);
        panel2.setBounds(0,205,500,150);
        panel2.setBackground(Color.BLACK);

        //PANEL3
        panel3.setLayout(null);
        panel3.setBounds(0,385,500,150);
        panel3.setBackground(Color.blue);

        //ADDING
        panel1.add(labelPic1);
        panel2.add(labelPic2);
        panel3.add(labelPic3);
        panel1.add(label1);
        panel2.add(label2);
        panel3.add(label3);


        panelMain.add(infoPanelJeep);
        panelMain.add(infoPanelHelicopter);
        panelMain.add(infoPanelMotor);
        panelMain.add(panel1);
        panelMain.add(panel2);
        panelMain.add(panel3);

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        this.add(panelMain);
        this.pack();
        this.setLocationRelativeTo(null);
        this.setVisible(true);

    }


}
