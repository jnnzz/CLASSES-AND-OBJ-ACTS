public class Jeepney implements Vehicle {

    @Override
    public void travel(String destination) {
        System.out.println("Travelling to " + destination + " by Jeepney.");
    }

}