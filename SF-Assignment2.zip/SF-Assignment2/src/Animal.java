// Animal.java
public abstract class Animal {
    //properties
    protected String species;
    protected String breed;
    protected Movable movementBehavior;

    //constructors
    public Animal(String species, String breed, Movable movementBehavior) {
        this.species = species;
        this.breed = breed;
        this.movementBehavior = movementBehavior;
    }

    //method
    public void move() {
        System.out.print(species + " is ");
        movementBehavior.doMove();
    }
}
