/*
Name: JAN LORENZ LAROCO
DATE: 11/10/2024
DESCRIPTION: SF Assignment #2: Animal Movement Simulation Using Interfaces and Anonymous Inner Classes/ Lambda Expressions
 */

public class Main {
    public static void main(String[] args) {
        System.out.printf("-----Name: Jan Lorenz Laroco-----\n");
        System.out.printf("--------SF Assignment #2-------\n");
        System.out.println();

        //anonymous inner class
        Animal dog = new Animal("Dog", "Bulldog", new Movable() {
            @Override
            public void doMove() {
                System.out.println("walking");
            }
        }) {};

        // Fish with lambda expression
        Animal fish = new Animal("Fish", "Goldfish", () -> System.out.println("swimming")) {};

        // Turtle lambda expression
        Animal turtle = new Animal("Turtle", "Green Turtle", () -> System.out.println("crawling")) {};

        // Simulate movement
        dog.move();
        fish.move();
        turtle.move();
    }
}
