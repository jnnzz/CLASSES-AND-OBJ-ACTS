public interface Movable {
    void doMove();
}
