import javax.swing.*;
import java.awt.*;


public class MyFrame extends JFrame {

    MyPanel panelMain;
    MyPanel panel1;
    MyPanel panel2;
    MyPanel panel3;

    JLabel label1 = new JLabel();
    JLabel label2 = new JLabel();
    JLabel label3 = new JLabel();
                                  JLabel labelPic1 = new JLabel();
                                  
                                  Image road;
    Image cars;
    Image helicopter;
    Image motor;


    MyFrame(){

        panelMain = new MyPanel();
        panel1 = new MyPanel();
        panel2 = new MyPanel();
        panel3 = new MyPanel();
                              
                              
                                      cars = new ImageIcon(getClass().getResource("jeep.png")).getImage();
                                      cars = cars.getScaledInstance(200, 100, Image.SCALE_SMOOTH);
                              
                              
                                      road = new ImageIcon(getClass().getResource("road.jpg")).getImage();
                                      road = road.getScaledInstance(850, 200, Image.SCALE_SMOOTH);
//BACKGROUND
        ImageIcon backgroundIcon = new ImageIcon(getClass().getResource("road.jpg")); // Load background image

        // Set up the background JLabel
        JLabel backgroundLabel = new JLabel(backgroundIcon);
        backgroundLabel.setLayout(new BorderLayout());

        helicopter = new ImageIcon(getClass().getResource("helicopter.jpg")).getImage();
        helicopter = helicopter.getScaledInstance(100, 200, Image.SCALE_SMOOTH);

        motor = new ImageIcon(getClass().getResource("motor.jpg")).getImage();
        motor = motor.getScaledInstance(100, 200, Image.SCALE_SMOOTH);

        label1.setText("hi everyone");
        label1.setIcon(new ImageIcon(road));
        label1.setBounds(0,0,700,150);
        label1.setHorizontalAlignment(JLabel.RIGHT);//add
                                               
                                               labelPic1.setText("hi everyone");
                                               labelPic1.setIcon(new ImageIcon(cars));
                                               labelPic1.setBounds(150,0,300,150);
                                               labelPic1.setHorizontalAlignment(JLabel.RIGHT);//addlabelPic1        
//        label1.setVerticalAlignment(JLabel.BOTTOM);
        label2.setIcon(new ImageIcon(helicopter));
        label2.setBounds(0,0,700,150);
        label3.setText("hi everyone");
        label3.setIcon(new ImageIcon(motor));
        label3.setBounds(0,0,700,150);

        panel1.setLayout(null); // Change layout to BorderLayout
        panel1.add(label1, BorderLayout.SOUTH); //add
        backgroundLabel.add(label1);
        panel1.add(backgroundLabel, BorderLayout.CENTER);
        panel1.setBounds(0,25,500,150);
        panel1.setBackground(Color.YELLOW);

        
        panel2.setLayout(null);
        panel2.setBounds(0,205,500,150);
        panel2.setBackground(Color.BLACK);


        panel3.setLayout(null);
        panel3.setBounds(0,385,500,150);
        panel3.setBackground(Color.blue);
         
        panel1.add(labelPic1);
        panel1.add(label1);
        panel2.add(label2);
        panel3.add(label3);


        panelMain.add(panel1);
        panelMain.add(panel2);
        panelMain.add(panel3);

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        this.add(panelMain);
        this.pack();
        this.setLocationRelativeTo(null);
        this.setVisible(true);

    }


}
