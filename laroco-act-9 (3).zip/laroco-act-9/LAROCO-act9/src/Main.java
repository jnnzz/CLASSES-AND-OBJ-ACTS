import javax.swing.*;
import java.awt.*;

public class Main {
    public static void main(String[] args) {

        new MyFrame();

        //positions sa panels
        //position sa text
        //animation sa panels

        //decouple/coupling
        //copy text from interface
    }
}