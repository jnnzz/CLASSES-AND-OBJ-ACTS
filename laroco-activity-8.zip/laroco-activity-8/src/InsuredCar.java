import javax.swing.*;

public class InsuredCar extends Vehicle implements Insured {
    //properties
    private int coverage;

    //constructor
    public InsuredCar(){
        super("gas", 4);
        setCoverage();
    }

    //setter
    public void setPrice(){
        String entry;
        final int MAX = 60000;
        boolean isValid = false;

        // Loop
        while (!isValid) {
            try {
                entry = JOptionPane.showInputDialog(null, "Enter car price (numbers only)");

                // Handle case when "Cancel" is pressed
                if (entry == null) {
                    price = 0;
                    JOptionPane.showMessageDialog(null, "Input cancelled. Setting price to 0.");
                    return;  // Exit
                }

                price = Integer.parseInt(entry);

                if (price > MAX) {
                    price = MAX;
                }
                isValid = true;
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Invalid input. Please enter numbers only.");
            }
        }
    }
    //setter
    public void setCoverage(){
        coverage = (int) (price * 0.9);
    }

    //getters
    public int getCoverage(){
        return coverage;
    }

    public String toString(){
        return("The insured car is powered by " +
                getPowerSource() + "; it has " + getWheels() +
                " wheels, costs $" + getPrice() +
                " and is insured for $" + getCoverage());
    }
}
