public interface Insured {
    public abstract void setCoverage();
    public abstract int getCoverage();
}
