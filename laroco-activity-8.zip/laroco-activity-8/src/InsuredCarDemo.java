/**
 * NAME: JAN LORENZ L. LAROCO
 * DATE: 10/20/24
 *
 **/

import javax.swing.*;

public class InsuredCarDemo {
    public static void main(String[] args) {
        int userChoice;

        do {
            InsuredCar myCar = new InsuredCar();
            JOptionPane.showMessageDialog(null, myCar.toString());
            userChoice = JOptionPane.showConfirmDialog(null, "Do you want to try again?","Try again",JOptionPane.YES_NO_OPTION);

        } while (userChoice == JOptionPane.YES_OPTION);
    }
}