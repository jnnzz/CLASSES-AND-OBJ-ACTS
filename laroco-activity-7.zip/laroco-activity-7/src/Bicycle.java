import javax.swing.*;

public class Bicycle extends Vehicle {

    // Constructor
    public Bicycle() {
        super("a person", 2);
    }

    // Override
    @Override
    public void setPrice() {
        String entry;
        final int MAX = 4000;
        boolean isValid = false;


        while (!isValid) {
            try {
                entry = JOptionPane.showInputDialog(null, "Enter bicycle price (numbers only)");


                if (entry == null) {
                    price = 0;
                    JOptionPane.showMessageDialog(null, "Input cancelled. Setting price to 0.");
                    return;  // Exit
                }

                price = Integer.parseInt(entry);

                if (price > MAX) {
                    price = MAX;  // Limit
                }

                isValid = true;
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Invalid input. Please enter numbers only.");
            }
        }
    }

    // Override
    @Override
    public String toString() {
        return ("The bicycle is powered by " + getPowerSource() +
                "; it has " + getWheels() + " wheels and costs $" + getPrice());
    }
}
