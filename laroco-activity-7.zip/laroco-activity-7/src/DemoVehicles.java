/**
 * NAME: JAN LORENZ L. LAROCO
 * DATE: 10/20/24
 *
 **/

import javax.swing.*;

public class DemoVehicles {
    public static void main(String[] args) {

        int userChoice;

        do {
            Sailboat aBoat = new Sailboat();
            Bicycle aBike = new Bicycle();

            JOptionPane.showMessageDialog(null, "\nVehicle descriptions:\n" + aBoat.toString()
                    + "\n" + aBike.toString());
            userChoice = JOptionPane.showConfirmDialog(null, "Do you want to try again?","Try again",JOptionPane.YES_NO_OPTION);

        } while (userChoice == JOptionPane.YES_OPTION);
    }

}