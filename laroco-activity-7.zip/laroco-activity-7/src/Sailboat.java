import javax.swing.*;

public class Sailboat extends Vehicle{

    private int length;

    //constructor
    public Sailboat(){
        super("wind", 0);
        setLength();
    }

    //setter&getters
    public void setLength(){
        String entry;
        boolean isValid = false;

        // Loop
        while (!isValid) {
            try {
                entry = JOptionPane.showInputDialog(null, "Enter sailboat length in feet (numbers only)");

                if (entry == null) {
                    length = 0;
                    JOptionPane.showMessageDialog(null, "Input cancelled. Setting length to 0.");
                    return;
                }

                length = Integer.parseInt(entry);
                isValid = true;
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Invalid input. Please enter numbers only.");
            }
        }
    }
    public int getLength(){
        return length;
    }

    //OVERRIDE
    @Override
    public void setPrice(){
        String entry;
        final int MAX = 100000;
        boolean isValid = false;

        // Loop
        while (!isValid) {
            try {
                entry = JOptionPane.showInputDialog(null, "Enter sailboat price (numbers only)");

                if (entry == null) {
                    price = 0;
                    JOptionPane.showMessageDialog(null, "Input cancelled. Setting price to 0.");
                    return;  // Exit
                }

                price = Integer.parseInt(entry);
                if (price > MAX) {
                    price = MAX;
                }
                isValid = true;
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Invalid input. Please enter numbers only.");
            }
        }
    }

    @Override
    public String toString(){
        return ("The "+ getLength() +
                " foot sailboat is powered by " +
                getPowerSource() + "; it has " + getWheels() +
                " wheels and costs $" + getPrice());

    }

}
