/*****
 * NAME: JAN LORENZ L. LAROCO
 * DATE: OCTOBER 5, 2024
 * DESCRIPTION: Midterm - Lab.Act.#05 - Classes and Objects (Encapsulation and Abstraction) Part 1
 ****/

import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        boolean indicator = true;
        Scanner scanner = new Scanner(System.in);

        System.out.printf("-----Welcome to Jan's Gadget Store-----\n");
        System.out.println("Choose a phone with your desired budget");
        System.out.println();

        while (indicator) {
            int choice = 0;
            boolean validInput = false;

            // Loop
            while (!validInput) {
                try {
                    System.out.printf("1. 5,000+\n");
                    System.out.printf("2. 10,000+\n");
                    System.out.printf("3. 15,000+\n");
                    System.out.printf("4. 20,000+\n\n");

                    System.out.printf("Choice: ");
                    choice = scanner.nextInt();

                    if (choice >= 1 && choice <= 4) {
                        validInput = true;
                    } else {
                        System.out.println("INVALID INPUT! Please choose a valid number between 1 and 4.");
                    }
                } catch (InputMismatchException e) {
                    System.out.println("INVALID INPUT! Please enter a number.");
                    scanner.next();
                }
            }

            // Display
            switch (choice) {
                case 1:
                    displayObj1();
                    break;
                case 2:
                    displayObj2();
                    break;
                case 3:
                    displayObj3();
                    break;
                case 4:
                    displayObj4();
                    break;
                default:
                    System.out.println("INVALID INPUT");
            }

            // Loop
            validInput = false;  // Reset validInput
            while (!validInput) {
                try {
                    System.out.printf("1. Choose budget again.\n");
                    System.out.printf("2. Exit.\n");
                    System.out.printf("Choice: ");
                    int choice2 = scanner.nextInt();

                    if (choice2 == 1) {
                        validInput = true; // Valid input, continue loop
                    } else if (choice2 == 2) {
                        System.out.printf("Thank you.\n");
                        validInput = true;
                        indicator = false; // Exit loop
                    } else {
                        System.out.println("INVALID INPUT! Please choose 1 or 2.");
                    }
                } catch (InputMismatchException e) {
                    System.out.println("INVALID INPUT! Please enter a number.");
                    scanner.next();
                }
            }
        }

        scanner.close();
    }

    //METHODS

    //OBJ1
    static void displayObj1() {
        Phones samsung1 = new Phones("Galaxy A06", 5790, 128, 4, 6.6);
        //call methods
        samsung1.info("----------SAMSUNG---------");
        samsung1.displaySpecs();
        System.out.println("--------------------------\n");

        Phones vivo1 = new Phones("Vivo Y17s", 5999, 128, 4, 6.56);
        //call methods
        vivo1.info("-----------VIVO-----------");
        vivo1.displaySpecs();
        System.out.println("--------------------------\n");

        Phones xiaomi1 = new Phones("Xiaomi Redmi 8A", 5490, 64, 2, 6.22);
        //call methods
        xiaomi1.info("----------XIAOMI----------");
        xiaomi1.displaySpecs();
        System.out.println("--------------------------\n");
    }

    //OBJ2
    static void displayObj2() {
        Phones samsung2 = new Phones("Galaxy A15", 10990, 128, 4, 6.3);
        //call methods
        samsung2.info("----------SAMSUNG---------");
        samsung2.displaySpecs();
        System.out.println();

        Phones vivo2 = new Phones("Vivo Y100", 10999, 256, 16, 6.5);
        //call methods
        vivo2.info("-----------VIVO-----------");
        vivo2.displaySpecs();
        System.out.println();

        Phones xiaomi2 = new Phones("Redmi Note 12s", 10999, 256, 8, 6.43);
        //call methods
        xiaomi2.info("----------XIAOMI----------");
        xiaomi2.displaySpecs();
        System.out.println();
    }

    //OBJ3
    static void displayObj3() {
        Phones samsung3 = new Phones("Samsung Galaxy A24", 14990, 128, 8, 6.5);
        //call methods
        samsung3.info("----------SAMSUNG---------");
        samsung3.displaySpecs();
        System.out.println();

        Phones vivo3 = new Phones("Vivo Y76 5G", 14999, 256, 12, 6.58);
        //call methods
        vivo3.info("-----------VIVO-----------");
        vivo3.displaySpecs();
        System.out.println();

        Phones xiaomi3 = new Phones("Redmi note 12 5G", 14999, 128, 8, 6.5);
        //call methods
        xiaomi3.info("----------XIAOMI----------");
        xiaomi3.displaySpecs();
        System.out.println();
    }

    //OBJ4
    static void displayObj4() {
        Phones samsung4 = new Phones("Samsung Galaxy A35 5G", 20990, 256, 8, 6.6);
        //call methods
        samsung4.info("----------SAMSUNG---------");
        samsung4.displaySpecs();
        System.out.println();

        Phones vivo4 = new Phones("Vivo V25", 21999, 256, 12, 6.65);
        //call methods
        vivo4.info("-----------VIVO-----------");
        vivo4.displaySpecs();
        System.out.println();

        Phones xiaomi4 = new Phones("Xiaomi 12 Lite", 20999, 256, 8, 6.55);
        //call methods
        xiaomi4.info("----------XIAOMI----------");
        xiaomi4.displaySpecs();
        System.out.println();
    }
}
