public class Phones {

    //PROPERTIES
    private String brand;
    private double price;
    private int storage;
    private int ram;
    private double size;
    private String info;

    //CONSTRUCTORS
    Phones(){

    }
    Phones(String info){
        this.info = info;
    }
    Phones(String brand, double price, int storage, int ram, double size){
        this.brand = brand;
        this.price = price;
        this.storage = storage;
        this.ram = ram;
        this.size = size;
    }

    //METHOD 1
    public void info(String info){
        System.out.printf(info);
        System.out.println();
    }
    //METHOD 2
    public void displaySpecs(){
        System.out.println("Brand   : "+brand);
        System.out.println("Price   : "+price);
        System.out.println("Storage : "+storage+ "gb");
        System.out.printf("RAM     : "+ram+"gb\n");
        System.out.printf("Size    : "+size+" inches display");
        System.out.println();

    }
}
