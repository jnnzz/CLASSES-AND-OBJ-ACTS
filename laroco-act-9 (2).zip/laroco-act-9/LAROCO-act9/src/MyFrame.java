import javax.swing.*;
import java.awt.*;


public class MyFrame extends JFrame {

    MyPanel panel1;
    MyPanel panel2;
    MyPanel panel3;
    MyPanel panel4;

    JLabel label1 = new JLabel();
    JLabel label2 = new JLabel();
    JLabel label3 = new JLabel();
    Image cars;


    MyFrame(){

        panel1 = new MyPanel();
        panel2 = new MyPanel();
        panel3 = new MyPanel();
        panel4 = new MyPanel();

        cars = new ImageIcon(getClass().getResource("jeep.png")).getImage();
        cars = cars.getScaledInstance(100, 200, Image.SCALE_SMOOTH);

        label1.setText("hi everyone");
        label1.setIcon(new ImageIcon(cars));
        label2.setText("hi everyone");
        label2.setIcon(new ImageIcon(cars));
        label3.setText("hi everyone");
        label3.setIcon(new ImageIcon(cars));


        panel2.setPreferredSize(new Dimension(500, 140));
        panel2.setBackground(Color.YELLOW);

        panel3.setPreferredSize(new Dimension(500, 140));
        panel3.setBackground(Color.BLACK);

        panel4.setPreferredSize(new Dimension(500, 140));
        panel4.setBackground(Color.blue);

        panel2.add(label1);
        panel3.add(label2);
        panel4.add(label3);



        panel1.add(panel2);
        panel1.add(panel3);
        panel1.add(panel4);

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        this.add(panel1);
        this.pack();
        this.setLocationRelativeTo(null);
        this.setVisible(true);

    }


}
