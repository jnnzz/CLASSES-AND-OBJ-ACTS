public class Cash implements PaymentMethod {

    @Override
    public void processPayment(double amount){
        System.out.printf("Received %.2f in cash as payment", amount);
    }
}
