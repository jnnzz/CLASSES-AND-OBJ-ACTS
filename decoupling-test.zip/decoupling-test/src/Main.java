public class Main {
    public static void main(String[] args) {

        double amount = 123.34;

        PaymentMethod paymentMethod = new Cash();

        Cashier cashier = new Cashier();
        cashier.setPaymentMethod(paymentMethod); //INJECTING THE DEPENDENCY
        cashier.getPayment(amount);



    }
}