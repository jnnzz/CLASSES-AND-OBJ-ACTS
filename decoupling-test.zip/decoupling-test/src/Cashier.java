public class Cashier {
    Cash cash = new Cash();
    CreditCard card = new CreditCard();
    PaymentMethod paymentMethod;

    public void setPaymentMethod (PaymentMethod paymentMethod){
        this.paymentMethod = paymentMethod;
    }

    public void getPayment(double amount){
        cash.processPayment(amount);
        card.processPayment(amount);
        paymentMethod.processPayment(amount);

    }
}
