public class Vehicle {

    //PROPERTIES
    public String name;
    public int maxSpeed;
    public double price;

    //CONSTRUCTORS
    public Vehicle(){

    }
    public Vehicle(String name, int maxSpeed, double price){
        this.name = name;
        this.maxSpeed = maxSpeed;
        this.price = price;
    }

    //METHOD OVERRIDE
    public void display(){
        System.out.println("Vehicle name   : "+name);
        System.out.println("Max Speed      : "+maxSpeed+" km/h");
        System.out.println("Price          : $"+price);
    }
}
