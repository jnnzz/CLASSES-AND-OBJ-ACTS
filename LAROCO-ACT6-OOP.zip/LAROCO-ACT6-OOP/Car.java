public class Car extends Vehicle{  //PROPERTIES

    //PROPERTIES
    private int doors;
    private String type;

    //CONSTRUCTORS
    public Car(){

    }
    public Car(String name, int maxSpeed, double price, int doors, String type){
        super(name,maxSpeed,price);
        this.doors = doors;
        this.type = type;
    }

    //METHOD OVERRIDE
    @Override
    public void display() {
        System.out.println("-----------------------------");
        System.out.println("Type of Vehicle: "+type);
        super.display();
        System.out.println("No. of Doors   : "+doors);

    }
}
