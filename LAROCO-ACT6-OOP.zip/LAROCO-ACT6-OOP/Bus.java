public class Bus extends Vehicle {

    //PROPERTIES
    private int doors;
    private String type;
    private int seat;

    //CONSTRUCTORS
    public Bus(){

    }
    public Bus(String name, int maxSpeed, double price, int doors, String type,int seat){
        super(name,maxSpeed,price);
        this.doors = doors;
        this.type = type;
        this.seat = seat;
    }

    //METHOD OVERRIDE
    @Override
    public void display(){
        System.out.println("-----------------------------");
        System.out.println("Vehicle type   : "+type);
        super.display();
        System.out.println("No. of doors   : "+doors);
        System.out.println("Passenger seats: "+ seat);
    }
}
