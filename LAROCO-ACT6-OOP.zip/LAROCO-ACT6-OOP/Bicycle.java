public class Bicycle extends Vehicle {

    //PROPERTIES
    private int seat;
    private String type;


    //CONSTRUCTORS
    public Bicycle(){

    }
    public Bicycle(String name, int maxSpeed, double price, String type, int seat){
        super(name, maxSpeed, price);
        this.type = type;
        this.seat = seat;
    }

    //METHOD OVERRIDE
    @Override
    public void display() {
        System.out.println("-----------------------------");
        System.out.println("Vehicle type   : " +type);
        super.display();
        System.out.printf("Number of seat  : " +seat);
        System.out.println();
    }
}
