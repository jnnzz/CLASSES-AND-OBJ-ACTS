/*****
 * NAME: JAN LORENZ L.LAROCO
 * DATE: OCTOBER 6, 2024,
 * DESCRIPTION: Midterm - Lab.Act.#06 - Classes and Objects (Inheritance and Polymorphism) Part 2
 ****/

import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner (System.in);
        boolean indicator = true;

        System.out.println("--------------NAME: JAN LORENZ L. LAROCO---------------");
        System.out.println("-------Midterm - Lab.Act.#06 - Classes and Objects-----");
        System.out.println();

        while(indicator) {
            int choice = 0;
            boolean input = true;
            while (input) {
                try {
                    System.out.println("Choose what type of vehicle do you want to purchase");
                    System.out.println("1. Car");
                    System.out.println("2. Bus");
                    System.out.println("3. Bicycle");
                    System.out.println();
                    System.out.printf("CHOICE: ");
                    choice = scanner.nextInt();

                    if (choice >= 1 && choice <= 3) {
                        input = false;
                    } else {
                        System.out.println("INVALID NUMBER. Enter 1-3 only");
                        System.out.println();
                    }
                    System.out.println();
                } catch (InputMismatchException e) {
                    System.out.println("INVALID INPUT! Please enter a number.");
                    System.out.println();
                    scanner.next();
                }
            }

            if (choice == 1) {
                displayOBJ1();
            } else if (choice == 2) {
                displayOBJ2();
            } else {
                displayOBJ3();
            }

            boolean validInput = false;  // Reset
            while (!validInput) {
                try {
                    System.out.println("-----------------------------");
                    System.out.printf("1. Choose again.\n");
                    System.out.printf("2. Exit.\n");
                    System.out.printf("Choice: ");
                    int choice2 = scanner.nextInt();

                    if (choice2 == 1) {
                        System.out.println();
                        validInput = true;//LOOP
                    } else if (choice2 == 2) {
                        indicator = false; //EXIT
                        validInput = true;
                        System.out.println();
                        System.out.println("THANK YOU!");
                    } else {
                        System.out.println("INVALID NUMBER!");
                        System.out.println();
                    }
                } catch (InputMismatchException e) {
                    System.out.println("INVALID INPUT! Please enter a number.");
                    System.out.println();
                    scanner.next();
                }
            }
        }
    }

    //METHODSS
    public static void displayOBJ1(){
        //OBJ1
        Vehicle[] vehicleCar = new Vehicle[3];
        vehicleCar[0] = new Car("SUV", 220, 1000, 4, "Car");
        vehicleCar[1] = new Car("Sedan", 210, 2000, 4, "Car");
        vehicleCar[2] = new Car("UAZ", 180, 3000, 4, "Car");
        //call method
        for(Vehicle vehicles : vehicleCar){
            vehicles.display();
        }
    }
    public static void displayOBJ2(){
        //OBJ2
        Vehicle[] vehicleBus = new Vehicle[3];
        vehicleBus[0] = new Bus("School Bus", 55, 1000, 2, "Bus", 30);
        vehicleBus[1] = new Bus("Shuttle Bus", 90, 1500, 2, "Bus", 20);
        vehicleBus[2] = new Bus("Minibus", 80, 1100, 2, "Bus", 8);
        //call method
        for(Vehicle vehicles : vehicleBus){
            vehicles.display();
        }
    }
    public static void displayOBJ3(){
        //OBJ3
        Vehicle[] vehicleBicycle = new Vehicle[3];
        vehicleBicycle[0] = new Bicycle("Mountain Bike", 30, 100, "Bicycle", 1);
        vehicleBicycle[1] = new Bicycle("BMX", 20, 120, "Bicycle", 1);
        vehicleBicycle[2] = new Bicycle("Road Bike", 30, 110, "Bicycle", 1);
        //call method
        for(Vehicle vehicles : vehicleBicycle){
            vehicles.display();
        }
    }
}