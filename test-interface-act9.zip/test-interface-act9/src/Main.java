public class Main {
    public static void main(String[] args) {

        // instance
        Student student = new Student();

        // Injecting
        Jeepney jeepney = new Jeepney();
        student.setVehicle(jeepney);
        student.travelTo("Mall");

        MotorcycleTaxi motorcycleTaxi = new MotorcycleTaxi();
        student.setVehicle(motorcycleTaxi);
        student.travelTo("University of Cebu");

        Helicopter helicopter = new Helicopter();
        student.setVehicle(helicopter);
        student.travelTo("Island");
    }
}