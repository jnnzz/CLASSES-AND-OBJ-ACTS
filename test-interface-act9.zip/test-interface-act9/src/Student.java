public class Student {
    private Vehicle vehicle;

    //dependency injection
    public void setVehicle(Vehicle vehicle) {
        this.vehicle = vehicle;
    }

    // destination
    public void travelTo(String destination) {
        vehicle.travel(destination);
    }
}