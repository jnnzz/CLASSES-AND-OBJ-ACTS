public interface Vehicle {

    void travel(String destination);

}