public class MotorcycleTaxi implements Vehicle {

    @Override
    public void travel(String destination) {
        System.out.println("Travelling to " + destination + " by Motorcycle Taxi.");
    }

}